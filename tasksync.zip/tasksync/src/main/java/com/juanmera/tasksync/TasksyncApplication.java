package com.juanmera.tasksync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TasksyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(TasksyncApplication.class, args);
	}

}
