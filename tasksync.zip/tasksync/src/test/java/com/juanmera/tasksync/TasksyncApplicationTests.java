package com.juanmera.tasksync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TasksyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
